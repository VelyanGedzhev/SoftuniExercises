﻿using System;
using System.Collections.Generic;
using System.Text;

namespace Vehicles.Models.Interfaces
{
    public interface IRefuel
    {
        public void Refuel(double amount);
    }
}
